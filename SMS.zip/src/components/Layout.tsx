
import { Outlet, Link } from 'react-router-dom'
import { Home, Users, BookOpen, GraduationCap } from 'lucide-react'

export default function Layout() {
  return (
    <div className="flex min-h-screen">
      <aside className="w-64 bg-blue-800 text-white p-4">
        <h1 className="text-2xl font-bold mb-8">School System</h1>
        <nav>
          <ul className="space-y-2">
            <li>
              <Link to="/" className="flex items-center gap-2 p-2 rounded hover:bg-blue-700">
                <Home size={18} /> Dashboard
              </Link>
            </li>
            <li>
              <Link to="/students" className="flex items-center gap-2 p-2 rounded hover:bg-blue-700">
                <Users size={18} /> Students
              </Link>
            </li>
            <li>
              <Link to="/teachers" className="flex items-center gap-2 p-2 rounded hover:bg-blue-700">
                <GraduationCap size={18} /> Teachers
              </Link>
            </li>
            <li>
              <Link to="/classes" className="flex items-center gap-2 p-2 rounded hover:bg-blue-700">
                <BookOpen size={18} /> Classes
              </Link>
            </li>
          </ul>
        </nav>
      </aside>
      <main className="flex-1 p-8 bg-gray-50">
        <Outlet />
      </main>
    </div>
  )
}
  